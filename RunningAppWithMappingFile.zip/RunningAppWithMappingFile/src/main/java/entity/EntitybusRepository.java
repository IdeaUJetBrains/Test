package entity;


import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EntitybusRepository extends CrudRepository<Entitybus, Long> {
    List<Entitybus> findByEnumber(String id);
}
